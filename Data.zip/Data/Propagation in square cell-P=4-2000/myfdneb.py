#!/usr/bin/env python
'''
finite deformation neb calculation for fake 2D system
'''
from ase import *
from ase.io import read,write
import os
import sys
import numpy as np

from ase.stressbox import stressbox
from ase.calculators.lammpsrun import LAMMPS

from tsase import neb

from ase import units

from ase.optimize.fire import FIRE 
from ase.optimize import BFGS
from tsase.optimize import BFGS
from tsase.optimize import MDMin

###################################### LAMMPS setting

atom_style = "atomic"
# parameter converted from the reference 
parameters = { 'units' : 'metal', 
               'atom_style':'atomic',
               'dimension':'2',
               'boundary': 'p p p', 
               'pair_style': 'hybrid/overlay lj/cut 4.5 gauss/cut 4.5',
               'pair_coeff': ['* * lj/cut 1 1'], 
               'pair_coeff_2': ['* * gauss/cut -0.3544 1.6 0.1414'] }

###################################### Read intial and final configurations

lmp_calc=LAMMPS(parameters=parameters)

press = 5 # Target pressure is press - 1

lj2GPa=160.2 # convert lj reduced units to GPa



load_lj = np.arange(0,press,1)
load_GPa =load_lj*lj2GPa # load is in reduced units

# load_GPa = press*lj2GPa


patom = read('size-16-layer0.data',format='lammps-data',style="atomic")
patom.set_calculator(lmp_calc)
fixstrain = np.ones((3,3))
pstress = patom.get_cell()*0.0

# pstress[0][0] = load_GPa
# pstress[1][1] = load_GPa

#layer = np.flip(np.arange(0,16,1))

layer = np.arange(0,16,1)


for ilayer in layer:

    initial_file = 'size-16-layer'+str(ilayer)+'.data'

    final_file = 'size-16-layer'+str(ilayer+1)+'.data'


    p1 = read(initial_file,format='lammps-data',style=atom_style)
    p2 = read(final_file,format='lammps-data',style=atom_style)
    p1.set_calculator(lmp_calc)
    p2.set_calculator(lmp_calc)


    for i in range(0,len(load_GPa)):
        pstress[0][0] = load_GPa[i]
        pstress[1][1] = load_GPa[i]
        p1box = stressbox(p1,express=pstress, fixstrain = fixstrain)
        dyn1=FIRE(p1box)
        dyn1.run(fmax=0.001,steps=2000)


    p1box = stressbox(p1,express=pstress, fixstrain = fixstrain)
    dyn1=FIRE(p1box)
    dyn1.run(fmax=0.001,steps=2000)


    write('initial.data', p1, format='lammps-data',atom_style='atomic')

    for i in range(0,len(load_GPa)):
        pstress[0][0] = load_GPa[i]
        pstress[1][1] = load_GPa[i]
        p2box = stressbox(p2,express=pstress, fixstrain = fixstrain)
        dyn2=FIRE(p2box)
        dyn2.run(fmax=0.001,steps=2000)

    p2box = stressbox(p2,express=pstress, fixstrain = fixstrain)
    dyn2=FIRE(p2box)
    dyn2.run(fmax=0.001,steps=2000)

    write('final.data', p2, format='lammps-data',atom_style='atomic')

    ##########################################################

    Rand_Cell_Flag = False

    Rand_Atom_Flag = True

    Rand_Atom_Mag = 0.001

    nim = 15 # number of images

    band = neb.fdneb_2d(p1, p2,  numImages = nim, method = 'ci', ss=True, fixstrain=fixstrain, express=pstress, weight=1,stress_type='hydro')

    opt = neb.fire_ssneb(band, maxmove =0.1, dtmax = 0.1, dt=0.1)
    opt.minimize(forceConverged=0.001, maxIterations = 2000)
    
    os.rename('fe.out',str(ilayer)+'fe.out')
    ##############################################################

    for p in range(len(band.path)):
        write('layer'+str(ilayer)+'-'+str(p)+".lmpdata",band.path[p], format='lammps-data',atom_style='atomic')
