#!/usr/bin/env python
'''
finite deformation neb calculation for fake 2D system
'''

from ase import *
from ase.io import read,write
import os
import sys
import numpy as np

from ase.stressbox import stressbox
from ase.calculators.lammpsrun import LAMMPS

from tsase import neb

from ase import units

from ase.optimize.fire import FIRE 
from ase.optimize import BFGS
from tsase.optimize import BFGS
from tsase.optimize import MDMin


atom_style = "atomic"

p1 = read('size-16-layer0.data',format='lammps-data',style=atom_style)
# p3 = read('special-2.data',format='lammps-data',style=atom_style)

p2 = read('size-16-layer1.data',format='lammps-data',style=atom_style)
# size-16-layer6
ref_coord = p1.get_cell() # used for compute P-K stress

# parameter converted from the reference 
parameters = { 'units' : 'metal', 
               'atom_style':'atomic',
               'dimension':'2',
               'boundary': 'p p p', 
               'pair_style': 'hybrid/overlay lj/cut 4.5 gauss/cut 4.5',
               'pair_coeff': ['* * lj/cut 1 1'], 
               'pair_coeff_2': ['* * gauss/cut -0.3544 1.6 0.1414'] }

lmp_calc=LAMMPS(parameters=parameters)


#lmp_path=os.getcwd()+'/lmp_dir'
#lmp_calc=LAMMPS(parameters=parameters,tmp_dir=lmp_path)

p1.set_calculator(lmp_calc)
p2.set_calculator(lmp_calc)
# p3.set_calculator(lmp_calc)


# define degree of freedom
fixstrain = np.ones((3,3))
fixstrain[2] *= 0.0

lj2GPa=160.2 # convert lj reduced units to GPa



# define stress
shear = 0

P = [4]

for press in P:
    pstress = p1.get_cell()*0.0
    pstress[0][0] = press*lj2GPa
    pstress[1][1] = press*lj2GPa
    pstress[1][0] = shear * lj2GPa
    pstress[0][1] = shear * lj2GPa

    # stress the system to targe stress
    p1box = stressbox(p1,express=pstress, fixstrain = fixstrain)
    dyn1=FIRE(p1box)
    dyn1.run(fmax=0.001,steps=500)


    p2box = stressbox(p2,express=pstress, fixstrain = fixstrain)
    dyn2=FIRE(p2box)
    dyn2.run(fmax=0.001,steps=500)

    Rand_Cell_Flag = False

    Rand_Atom_Flag = True

    Rand_Atom_Mag = 0.001

    nim = 15 # number of images

    band = neb.fdneb_2d(p1, p2,  numImages = nim, method = 'ci', ss=True, fixstrain=fixstrain, express=pstress,weight=1,stress_type='hydro')


    opt = neb.fire_ssneb(band, maxmove =0.1, dtmax = 0.1, dt=0.1)
    opt.minimize(forceConverged=0.001, maxIterations = 2000)

    os.rename('fe.out',str(press)+'fe.out')


    for p in range(len(band.path)):
        write('press'+str(press)+'-'+str(p)+".lmpdata",band.path[p], format='lammps-data',atom_style='atomic')

